package repositorios;

import entidades.Aposta;
import java.util.LinkedList;
import java.util.Queue;

public class RepositorioApostaFila {

    private Queue<Aposta> filaApostas;

    public RepositorioApostaFila() {
        this.filaApostas = new LinkedList<>();
    }

    // Inserir aposta na fila (FIFO)
    public void inserir(Aposta aposta) {
        filaApostas.add(aposta);
    }

    // Remover a próxima aposta da fila
    public Aposta remover() {
        return filaApostas.poll(); // retorna null se a fila estiver vazia
    }

    // Pesquisar aposta pelo ID
    public Aposta pesquisar(String id) {
        for (Aposta aposta : filaApostas) {
            if (aposta.getId().equals(id)) {
                return aposta;
            }
        }
        return null;
    }

    // Ver tamanho da fila
    public int tamanho() {
        return filaApostas.size();
    }

    // Verificar se a fila está vazia
    public boolean estaVazia() {
        return filaApostas.isEmpty();
    }

    // Mostrar todas as apostas na fila (opcional)
    public void listarApostas() {
        for (Aposta aposta : filaApostas) {
            System.out.println(aposta);
        }
    }
}
