package repositorios;

import entidades.Carteira;

/**
 * Interface específica para Repositório de Carteira.
 * Estende a interface genérica RepositorioInterface<Carteira>.
 */
public interface IRepositorioCarteira extends RepositorioInterface<Carteira> {
}
