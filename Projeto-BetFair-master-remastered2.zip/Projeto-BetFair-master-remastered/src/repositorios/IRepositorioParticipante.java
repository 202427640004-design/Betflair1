package repositorios;

import entidades.Participante;

/**
 * Interface específica para Repositorio de Participante.
 */
public interface IRepositorioParticipante extends RepositorioInterface<Participante> {
}
