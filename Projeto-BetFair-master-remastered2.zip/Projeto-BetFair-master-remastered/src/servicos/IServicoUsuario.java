package servicos;

import entidades.Usuario;

/**
 * Interface específica para serviço de Usuario.
 * Extende a interface genérica ServicoInterface<Usuario>.
 */
public interface IServicoUsuario extends ServicoInterface<Usuario> {
}
