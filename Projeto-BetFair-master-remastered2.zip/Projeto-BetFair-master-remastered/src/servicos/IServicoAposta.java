package servicos;

import entidades.Aposta;

/**
 * Interface específica para serviço de Aposta.
 * Estende a interface genérica ServicoInterface<Aposta>.
 */
public interface IServicoAposta extends ServicoInterface<Aposta> {
}
